package com.example.Bookstore.Controllers;

import com.example.Bookstore.Models.Book;
import com.example.Bookstore.Services.BookService;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/books")
public class BookController {

    private final BookService bookService;

    public BookController(BookService bookService) {
        this.bookService = bookService;
    }

    @GetMapping
    public List<Book> getAllBooks() {
        return bookService.findAll();
    }

    @GetMapping("/{id}")
    public Book getBookById(@PathVariable Integer id) {
        return bookService.findById(id);
    }

    @GetMapping("/isbn/{isbn}")
    public Book getBookByIsbn(@PathVariable String isbn) {
        return bookService.findByIsbn(isbn);
    }

    @GetMapping("/title")
    public List<Book> getBooksByTitle(@RequestParam("name") String title) {
        return bookService.findByTitleContainingIgnoreCase(title);
    }

    @PostMapping
    public Book createBook(@RequestBody Book book) {
        return bookService.save(book);
    }

  
    @PutMapping("/{id}")
    public Book updateBook(@PathVariable Integer id, @RequestBody Book request) {
        Book existing = bookService.findById(id);
        if (existing == null) {
            throw new RuntimeException("Libro no encontrado con ID: " + id);
        }
        existing.setTitle(request.getTitle());
        existing.setIsbn(request.getIsbn());
        existing.setPrice(request.getPrice());
        existing.setImageUrl(request.getImageUrl());
        existing.setStock(request.getStock());
        existing.setCategory(request.getCategory());
        existing.setPublicationDate(request.getPublicationDate());
        existing.setStatus(request.getStatus());
        return bookService.save(existing);
    }

    @DeleteMapping("/{id}")
    public void deleteBook(@PathVariable Integer id) {
        bookService.deleteById(id);
    }
}
