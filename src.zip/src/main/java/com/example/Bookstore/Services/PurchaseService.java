package com.example.Bookstore.Services;

import com.example.Bookstore.DTO.PurchaseRequest;
import com.example.Bookstore.Models.Book;
import com.example.Bookstore.Models.MembershipCard;
import com.example.Bookstore.Models.Purchase;
import com.example.Bookstore.Models.PurchaseDetails;
import com.example.Bookstore.Models.User;
import com.example.Bookstore.Repositories.BookRepository;
import com.example.Bookstore.Repositories.MembershipCardRepository;
import com.example.Bookstore.Repositories.PurchaseDetailsRepository;
import com.example.Bookstore.Repositories.PurchaseRepository;
import com.example.Bookstore.Repositories.UserRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
public class PurchaseService {

    private final BookRepository bookRepository;
    private final MembershipCardRepository cardRepository;
    private final PurchaseRepository purchaseRepository;
    private final PurchaseDetailsRepository purchaseDetailsRepository;
    private final UserRepository userRepository;

    public PurchaseService(BookRepository bookRepository,
                           MembershipCardRepository cardRepository,
                           PurchaseRepository purchaseRepository,
                           PurchaseDetailsRepository purchaseDetailsRepository,
                           UserRepository userRepository) {
        this.bookRepository = bookRepository;
        this.cardRepository = cardRepository;
        this.purchaseRepository = purchaseRepository;
        this.purchaseDetailsRepository = purchaseDetailsRepository;
        this.userRepository = userRepository;
    }

    @Transactional
    public String makePurchase(PurchaseRequest request) {
        // 1) Verificar tarjeta
        MembershipCard card = cardRepository.findById(request.getCardId())
            .orElseThrow(() -> new RuntimeException("Tarjeta no encontrada"));

        // 2) Verificar usuario
        User user = userRepository.findById(request.getUserId())
            .orElseThrow(() -> new RuntimeException("Usuario no encontrado"));

        double totalPrice = 0.0;

        // 3) Recorrer la lista de libros a comprar
        for (PurchaseRequest.BookPurchase item : request.getBooks()) {
            Book book = bookRepository.findById(item.getBookId())
                .orElseThrow(() -> new RuntimeException("Libro no encontrado"));

            // Verificar stock
            if (book.getStock() < item.getQuantity()) {
                throw new RuntimeException("Stock insuficiente para el libro: " + book.getTitle());
            }
            totalPrice += book.getPrice() * item.getQuantity();
        }

        // 4) Verificar saldo
        if (card.getBalance() < totalPrice) {
            throw new RuntimeException("Saldo insuficiente en la tarjeta");
        }

        // 5) Descontar saldo
        card.setBalance(card.getBalance() - totalPrice);
        cardRepository.save(card);

        // 6) Crear compra
        Purchase purchase = new Purchase();
        purchase.setUser(user);
        purchase.setMembershipCard(card);
        purchase.setTotal(totalPrice);
        purchase.setStatus((byte) 1);
        purchaseRepository.save(purchase);

        // 7) Crear detalles y actualizar stock
        for (PurchaseRequest.BookPurchase item : request.getBooks()) {
            Book book = bookRepository.findById(item.getBookId()).get(); // Validado arriba
            book.setStock(book.getStock() - item.getQuantity());
            bookRepository.save(book);

            PurchaseDetails detail = new PurchaseDetails();
            detail.setPurchase(purchase);
            detail.setBook(book);
            detail.setQuantity(item.getQuantity());
            detail.setUnitPrice(book.getPrice());
            detail.setSubtotal(book.getPrice() * item.getQuantity());
            purchaseDetailsRepository.save(detail);
        }

        return "Compra realizada con éxito";
    }

    // CREATE/UPDATE
    public Purchase save(Purchase purchase) {
        return purchaseRepository.save(purchase);
    }

    // READ (todos)
    public List<Purchase> findAll() {
        return purchaseRepository.findAll();
    }

    // READ (uno por ID)
    public Purchase findById(Integer id) {
        return purchaseRepository.findById(id).orElse(null);
    }

    // DELETE
    public void deleteById(Integer id) {
        purchaseRepository.deleteById(id);
    }
}
